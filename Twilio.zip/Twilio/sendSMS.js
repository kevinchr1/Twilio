// Importering af Twilio
const twilio = require('twilio');

// Twilio-kontooplysninger
const accountSid = 'ACdacb4f6f4e67302dac42dde44a2db59e';
const authToken = '5cc96b85664fa2a2b05c40b049f5aaee';
const client = new twilio(accountSid, authToken);

// Funktion til at sende SMS
function sendLowStockAlert(itemName, manager) {
    const messageBody = `Advarsel: Lavt lagerantal for ${itemName}`;

    client.messages
        .create({
            body: messageBody,
            to: manager,
            from: '+16193596989' //Twilio-nummer
        })
        .then(message => console.log(message.sid))
        .catch(error => console.error(error));
}

// Eksempel på brug
sendLowStockAlert('Appelsinjuice', '+4560136380'); //Kevins nummer 
